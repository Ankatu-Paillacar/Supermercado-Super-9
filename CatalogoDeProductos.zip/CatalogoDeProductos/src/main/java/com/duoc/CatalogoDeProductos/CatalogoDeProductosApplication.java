package com.duoc.CatalogoDeProductos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoDeProductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoDeProductosApplication.class, args);
	}

}
