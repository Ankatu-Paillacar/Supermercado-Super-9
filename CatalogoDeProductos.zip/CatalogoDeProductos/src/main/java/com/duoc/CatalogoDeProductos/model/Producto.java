package com.duoc.CatalogoDeProductos.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Producto {

    private int idProducto;
    private String nombreProducto;
    private String descripcion;
    private String categoria;
    private String marca;
    private double precio; 
    
}
