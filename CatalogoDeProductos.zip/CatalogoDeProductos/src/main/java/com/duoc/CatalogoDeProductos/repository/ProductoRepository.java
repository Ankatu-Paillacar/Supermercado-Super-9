package com.duoc.CatalogoDeProductos.repository;


import com.duoc.CatalogoDeProductos.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductoRepository {

    private List<Producto> listaProductos = new ArrayList<>();

    public ProductoRepository() {
        // Agregar algunos productos de ejemplo
        listaProductos.add(new Producto( 1,  "Arroz", "Arroz de alta calidad", "Alimentos", "Marca A", 20.00));
        listaProductos.add(new Producto( 2, "Leche", "Leche fresca", "Alimentos", "Marca B", 15.00));
        listaProductos.add(new Producto( 3, "Cereal", "Cereal saludable", "Alimentos", "Marca C", 25.00));
        listaProductos.add(new Producto( 4, "Jabón", "Jabón antibacterial", "Higiene", "Marca D", 10.00));
        listaProductos.add(new Producto( 5, "Shampoo", "Shampoo para cabello seco", "Higiene", "Marca E", 30.00));
        listaProductos.add(new Producto( 6, "Detergente", "Detergente para ropa", "Limpieza", "Marca F", 18.00));
        listaProductos.add(new Producto( 7, "Pasta de dientes", "Pasta de dientes blanqueadora", "Higiene", "Marca G", 12.00));
        listaProductos.add(new Producto( 8, "Café", "Café molido de alta calidad", "Bebidas", "Marca H", 22.00));
        listaProductos.add(new Producto( 9, "Té", "Té verde orgánico", "Bebidas", "Marca I", 18.00));
        listaProductos.add(new Producto( 10, "Galletas", "Galletas de chocolate", "Alimentos", "Marca J", 8.00));
    }

    public List<Producto> obtenerProducto(){
        return listaProductos;
    }

    public Producto buscarProId(int idProducto){
        for (Producto producto : listaProductos) {
            if (producto.getIdProducto() == idProducto) {
                return producto;
            }
        }
        return null; // Retorna null si no se encuentra el producto
    }

    public Producto agregarProducto(Producto producto){
        listaProductos.add(producto);
        return producto;
    }

    public Producto actualizarProducto(int idProducto, Producto productoActualizado){
        for (Producto producto : listaProductos) {
            if (producto.getIdProducto() == idProducto) {
                producto.setNombreProducto(productoActualizado.getNombreProducto());
                producto.setDescripcion(productoActualizado.getDescripcion());
                producto.setCategoria(productoActualizado.getCategoria());
                producto.setMarca(productoActualizado.getMarca());
                producto.setPrecio(productoActualizado.getPrecio());
                return producto;
            }
        }
        return null; // Retorna null si no se encuentra el producto
    }

    public boolean eliminarProducto(int idProducto){
        return listaProductos.removeIf(producto -> producto.getIdProducto() == idProducto);
    }

    public int totalProductos(){
        return listaProductos.size();
    }

    public List<Producto> buscarPrecioProductos(double precioMinimo, double precioMaximo){
        List<Producto> productosEncontrados = new ArrayList<>();
        for (Producto producto : listaProductos) {
            if (producto.getPrecio() >= precioMinimo && producto.getPrecio() <= precioMaximo) {
                productosEncontrados.add(producto);
            }
        }
        return productosEncontrados;
    }
    
}
