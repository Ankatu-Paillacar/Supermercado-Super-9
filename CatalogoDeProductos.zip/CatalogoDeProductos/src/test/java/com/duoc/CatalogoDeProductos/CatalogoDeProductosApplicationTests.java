package com.duoc.CatalogoDeProductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoDeProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
