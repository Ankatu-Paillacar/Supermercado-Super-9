package com.duoc.CatalogoDeProductos.controller;

import com.duoc.CatalogoDeProductos.model.Producto;
import com.duoc.CatalogoDeProductos.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    @Autowired
    private ProductoService ProductoService;

    @GetMapping
    public List<Producto> ListarProductos(){
        return ProductoService.getProducto();
    }

    @PostMapping
    public Producto agregarProducto(@RequestBody Producto producto){
        return ProductoService.newProducto(producto);
    }

    @GetMapping("{idproducto}")
    public Producto buscarProducto(@PathVariable int idproducto){
        return ProductoService.getProductoId(idproducto);
    }

    @PutMapping("{idproducto}")
    public Producto actualizarProducto(@PathVariable int idproducto, @RequestBody Producto Producto){
        return ProductoService.updateProducto(idproducto, Producto);
    }

    @DeleteMapping("{idproducto}")
    public String eliminarProducto(@PathVariable int idproducto){
        return ProductoService.deleteProducto(idproducto);
    }

    @GetMapping("/total")
    public int totalProductosV2(){
        return ProductoService.totalProductosV2();
    }
    
}
