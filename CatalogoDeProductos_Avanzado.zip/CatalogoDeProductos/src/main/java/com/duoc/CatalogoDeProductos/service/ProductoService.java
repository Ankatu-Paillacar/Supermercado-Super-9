package com.duoc.CatalogoDeProductos.service;

import com.duoc.CatalogoDeProductos.model.Producto;
import com.duoc.CatalogoDeProductos.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;
    
    public List<Producto> getProducto(){
        return productoRepository.obtenerProducto();
    }

    public Producto newProducto(Producto producto){
        return productoRepository.agregarProducto(producto);
    }

    public Producto updateProducto(int idProducto, Producto productoActualizado){
        return productoRepository.actualizarProducto(idProducto, productoActualizado);
    }

    public String deleteProducto(int idProducto){
        productoRepository.eliminarProducto(idProducto);
        return "producto eliminado";
    }

    public Producto getProductoId(int idProducto){
        return productoRepository.buscarPorId(idProducto);
    }

    public int totalProductos(){
        return productoRepository.obtenerProducto().size();
    }

    public int totalProductosV2(){
        return productoRepository.totalProductos();
    }


}
