package com.duoc.pagos.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pago {
    private Long idPago;
    private Integer rut;
    private String dv;
    private String nombre;
    private String apellido;
    private String direccion;
    private String email;
    private int telefono;
    private String ciudad;
    private String codigoPostal;
    private String pais;
    private String region;
    private String comuna;
}
