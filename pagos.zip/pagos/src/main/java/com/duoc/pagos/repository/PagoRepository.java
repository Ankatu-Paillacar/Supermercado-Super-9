package com.duoc.pagos.repository;

import com.duoc.pagos.model.Pago;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PagoRepository {
    private List<Pago> listaPagos = new ArrayList<>();


    public PagoRepository(){
        listaPagos.add(new Pago(434175L ,123456789, "k","Torune" , "Hagakure", "Alvarez 123", "torunehagakure@gmail.cl", 12345678, "Valparaiso", "2345678", "chile" , "valparaiso", "comuna1"));
    }

    public List<Pago> obtenerPagos(){
        return listaPagos;
    }

    public Pago buscarPorId(Long id){
        for (Pago p : listaPagos) {
            if(p.getIdPago() == id){
                return p;
            }
        }
        return null;
    }

    public Pago buscarPorRut(Integer rut){
        for (Pago p: listaPagos) {
            if(p.getRut().equals(rut)){
                return p;
            }

        }
        return null;
    }


    public Pago guardar(Pago pago){
        listaPagos.add(pago);
        return pago;
    }

    public Pago actualizarPago(Pago pago) {
        Long idPago = 0L;
        int idPosicion = 0;

        for (int i = 0; i < listaPagos.size(); i++){
            if(listaPagos.get(i).getIdPago() == pago.getIdPago()){
                idPago = pago.getIdPago();
                idPosicion = i;
            }
        }

        Pago pago1 = new Pago();
        pago1.setIdPago(idPago);
        pago1.setRut(pago.getRut());
        pago1.setDv(pago.getDv());
        pago1.setNombre(pago.getNombre());
        pago1.setApellido(pago.getApellido());
        pago1.setDireccion(pago.getDireccion());
        pago1.setEmail(pago.getEmail());
        pago1.setTelefono(pago.getTelefono());
        pago1.setCiudad(pago.getCiudad());
        pago1.setCodigoPostal(pago.getCodigoPostal());
        pago1.setPais(pago.getPais());
        pago1.setRegion(pago.getRegion());
        pago1.setComuna(pago.getComuna());

        listaPagos.set(idPosicion, pago1);
        return pago1;
    }

    public void eliminar(Long id) {
        Pago pago = buscarPorId(id);
       if (pago != null) {
            listaPagos.remove(pago);
       }


}

 public int totalPagos() {
        return listaPagos.size();
    }
}
