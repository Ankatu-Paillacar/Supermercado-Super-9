package com.duoc.pagos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.duoc.pagos.model.Pago;
import com.duoc.pagos.service.PagoService;

@RestController
@RequestMapping("/api/v1/pagos")
public class PagoController {
    @Autowired
    private PagoService pagoService;

    @GetMapping
    public List<Pago> listarPagos(){
        return pagoService.getPagos();
    }

    @PostMapping

    public Pago agregarPago(@RequestBody Pago pago){
        return pagoService.savePago(pago);
    }

    @GetMapping("{id}")

    public Pago buscarPago(@PathVariable long id){
        return pagoService.getPagoId(id);
    }

    @PutMapping("{id}")
    public Pago actualizarPago(@PathVariable long id, @RequestBody Pago pago){
        pago.setIdPago(id); 
        return pagoService.updatePago(pago);
    }

    @DeleteMapping("{id}")
    public String eliminarPago(@PathVariable long id) {
        return pagoService.deletePago(id);
    }

    @GetMapping("/total")
    public int totalPagosV2() {
        return pagoService.totalPagosV2();
    }




}
