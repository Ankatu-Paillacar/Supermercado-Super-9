package com.duoc.pagos.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "PAGO")
@AllArgsConstructor
@NoArgsConstructor

public class Pago {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPago;
    private Integer rut;
    private String dv;
    private String nombre;
    private String apellido;
    private String direccion;
    private String email;
    private int telefono;
    private String ciudad;
    private String codigoPostal;
    private String pais;
    private String region;
    private String comuna;
}
