package com.duoc.pagos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.pagos.model.Pago;
import com.duoc.pagos.repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
private PagoRepository pagoRepository;

    public List<Pago> getPagos() {
        return pagoRepository.findAll();
    }

    public Pago savePago(Pago pago) {
        return pagoRepository.save(pago);
    }

    public Pago getPagoId(Long id) {
        Optional<Pago> pago = pagoRepository.findById(id);
        return pago.orElse(null);
    }

    public Pago updatePago(Pago pago) {
        return pagoRepository.save(pago);
    }

    public String deletePago(Long id) {
        pagoRepository.deleteById(id);
        return "Pago eliminado";
    }

    public int totalPagosV2() {
        return (int) pagoRepository.count();
    }
}
